#ifndef AUDIO_MANAGER_H
#define AUDIO_MANAGER_H

#include <Arduino.h>
#include <driver/i2s.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <M5Atom.h>
#include "config.h"

// Forward-Deklaration
class EventManager;

// Audio-Zustände - klar und einfach
enum class AudioState {
    IDLE,
    RECORDING,
    PLAYING
};

// Audio-Ring-Puffer (unverändert)
struct AudioRingBuffer {
    uint8_t* buffer;
    size_t size;
    size_t readIndex;
    size_t writeIndex;
    size_t available;
    bool isFull;
    bool isEmpty;
};

// Audio-Chunk für Streaming
struct AudioChunk {
    uint8_t* data;
    size_t length;
    unsigned long timestamp;
    bool isSilence;
};

class AudioManager {
public:
    // Konstruktor & Destruktor
    AudioManager();
    ~AudioManager();
    
    // Initialisierung
    bool begin();
    void update();
    
    // Mikrofon-Steuerung
    bool startRecording();
    void stopRecording(); // Gibt jetzt void zurück, da es den Stopp erzwingt
    bool isRecording() const;
    size_t getAvailableAudioDataSize();
    size_t readAudioData(uint8_t* buffer, size_t maxLength);
    
    // Lautsprecher-Steuerung
    bool playAudioChunk(const uint8_t* data, size_t length);
    void stopPlaying(); // Erzwingt den Stopp
    bool isPlaying() const;
    
    // Kompatibilität mit bestehendem Code
    size_t getAvailableAudio() { return getAvailableAudioDataSize(); }
    size_t readAudio(uint8_t* buffer, size_t maxLength) { return readAudioData(buffer, maxLength); }
    bool writeAudio(const uint8_t* data, size_t length) { return playAudioChunk(data, length); }
    bool writeAudioChunk(const AudioChunk& chunk) { return playAudioChunk(chunk.data, chunk.length); }
    
    // Puffer-Management
    void clearMicBuffer();
    void clearSpeakerBuffer();
    size_t getMicBufferAvailable() const;
    size_t getSpeakerBufferAvailable() const;
    
    // Audio-Konfiguration
    void setSampleRate(uint32_t sampleRate);
    void setBitsPerSample(uint8_t bitsPerSample);
    void setChannels(uint8_t channels);
    uint32_t getSampleRate() const;
    uint8_t getBitsPerSample() const;
    uint8_t getChannels() const;
    
    // Zustandsabfrage
    AudioState getState() const;
    bool isSilence() const;
    bool isBufferFull() const;
    bool isBufferEmpty() const;
    
    // Utility-Methoden
    void reset();
    void setSilenceThreshold(int threshold);
    int getSilenceThreshold() const;
    unsigned long getLastAudioTimestamp() const;
    
    // Debug-Methoden
    void printBufferStatus();
    void printAudioStats();
    
    // Event-Integration
    void setEventManager(EventManager* manager);
    bool playChunk(const uint8_t* data, size_t size);
    
    // Test-Funktionen
    bool playTestTone();
    
    // Debug-Funktionen
    uint16_t getCurrentAudioLevel();
    
    // Audio-Verstärkung (entsprechend dem Beispiel)
    void amplifyAudioData(uint8_t* data, size_t length);
    
    // M5Atom.h-basierte I2S-Initialisierung (bewährte Lösung)
    void InitI2SSpeakerOrMic(int mode);

private:
    // --- Interne Zustandsverwaltung ---
    AudioState m_currentState;
    SemaphoreHandle_t m_audioMutex;
    
    // --- Puffer ---
    AudioRingBuffer m_micBuffer;
    AudioRingBuffer m_speakerBuffer;
    uint8_t* m_micBufferData;
    uint8_t* m_speakerBufferData;
    
    // Puffer für Audio-Level-Berechnung
    uint8_t* m_lastMicBuffer;
    size_t m_lastMicBufferSize;
    
    // --- FreeRTOS Tasks ---
    TaskHandle_t m_recordingTaskHandle;
    TaskHandle_t m_playingTaskHandle;
    
    // Volatile Flags zur Steuerung der Tasks von außerhalb
    volatile bool m_isRecordingTaskRunning;
    volatile bool m_isPlayingTaskRunning;
    
    // Audio-Verarbeitung
    unsigned long m_lastAudioProcess;
    int m_silenceCounter;
    bool m_isSilenceDetected;
    int m_silenceThreshold;
    
    // Event-Manager Referenz
    EventManager* m_eventManager;
    
    // --- Task-Funktionen (statisch) ---
    static void recordingTask(void* parameter);
    static void playingTask(void* parameter);
    
    // --- Private Hilfsfunktionen ---
    void changeState(AudioState newState);

    // Puffer-Management
    void initRingBuffer(AudioRingBuffer& rb, uint8_t* buffer, size_t size);
    void resetRingBuffer(AudioRingBuffer& rb);
    size_t writeToRingBuffer(AudioRingBuffer& rb, const uint8_t* data, size_t length);
    size_t readFromRingBuffer(AudioRingBuffer& rb, uint8_t* data, size_t maxLength);

    // I2S-Management
    void installI2SDriver(int mode);
    void uninstallI2SDriver();

    // Audio-Verarbeitung
    bool detectSilence(const uint8_t* data, size_t length);
    
    // Verstärker-Steuerung
    void enableAmplifier();
    void disableAmplifier();
};

#endif // AUDIO_MANAGER_H
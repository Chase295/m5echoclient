#include "AudioManager.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
#include <driver/i2s.h>
#include <soc/i2s_reg.h>
#include <soc/i2s_struct.h>

// Externe Funktion für Logging
extern void logToWebClients(const char* message);

// Externe Variable für Debug-Modus
extern volatile bool micDebugModeActive;

// =============================================================================
// KONSTRUKTOR & DESTRUKTOR
// =============================================================================

AudioManager::AudioManager() : 
    m_currentState(AudioState::IDLE),
    m_audioMutex(nullptr),
    m_micBufferData(nullptr),
    m_speakerBufferData(nullptr),
    m_lastMicBuffer(nullptr),
    m_lastMicBufferSize(0),
    m_recordingTaskHandle(nullptr),
    m_playingTaskHandle(nullptr),
    m_isRecordingTaskRunning(false),
    m_isPlayingTaskRunning(false),
    m_lastAudioProcess(0),
    m_silenceCounter(0),
    m_isSilenceDetected(false),
    m_silenceThreshold(AUDIO_SILENCE_THRESHOLD),
    m_eventManager(nullptr)
{
    // Konstruktor-Initialisierungsliste ist sauberer
}

AudioManager::~AudioManager() {
    // Tasks stoppen
    if (m_recordingTaskHandle) {
        m_isRecordingTaskRunning = false;
        vTaskDelay(pdMS_TO_TICKS(100));
        if (m_recordingTaskHandle) {
            vTaskDelete(m_recordingTaskHandle);
        }
    }
    if (m_playingTaskHandle) {
        m_isPlayingTaskRunning = false;
        vTaskDelay(pdMS_TO_TICKS(100));
        if (m_playingTaskHandle) {
            vTaskDelete(m_playingTaskHandle);
        }
    }
    
    // Mutex löschen
    if (m_audioMutex) {
        vSemaphoreDelete(m_audioMutex);
    }
    
    // Puffer freigeben
    if (m_micBufferData) {
        free(m_micBufferData);
    }
    if (m_speakerBufferData) {
        free(m_speakerBufferData);
    }
    if (m_lastMicBuffer) {
        free(m_lastMicBuffer);
    }
    
    // I2S-Ports schließen
    i2s_driver_uninstall(I2S_NUM_0);
}

// =============================================================================
// INITIALISIERUNG
// =============================================================================

bool AudioManager::begin() {
    Serial.println("AudioManager: Initialisiere...");
    
    m_audioMutex = xSemaphoreCreateMutex();
    if (!m_audioMutex) {
        Serial.println("AudioManager: Fehler beim Erstellen des Mutex");
        return false;
    }
    
    m_micBufferData = (uint8_t*)malloc(AUDIO_RING_BUFFER_SIZE);
    m_speakerBufferData = (uint8_t*)malloc(AUDIO_RING_BUFFER_SIZE);
    m_lastMicBuffer = (uint8_t*)malloc(I2S_BUFFER_SIZE);
    
    if (!m_micBufferData || !m_speakerBufferData || !m_lastMicBuffer) {
        Serial.println("AudioManager: Fehler beim Allozieren der Audio-Puffer");
        return false;
    }
    
    initRingBuffer(m_micBuffer, m_micBufferData, AUDIO_RING_BUFFER_SIZE);
    initRingBuffer(m_speakerBuffer, m_speakerBufferData, AUDIO_RING_BUFFER_SIZE);

    // Verstärker-Pin initialisieren und ausschalten
    pinMode(SPEAKER_ENABLE_PIN, OUTPUT);
    digitalWrite(SPEAKER_ENABLE_PIN, LOW);
    
    Serial.println("AudioManager: Initialisierung abgeschlossen");
    return true;
}

void AudioManager::update() {
    // Audio-Verarbeitung in der Hauptschleife
    unsigned long currentTime = millis();
    
    if (currentTime - m_lastAudioProcess > 10) { // 100Hz Update-Rate
        m_lastAudioProcess = currentTime;
        
        // Stille-Erkennung für Mikrofon
        if (m_currentState == AudioState::RECORDING) {
            // Hier könnte zusätzliche Audio-Verarbeitung stattfinden
        }
    }
}

// =============================================================================
// MIKROFON-STEUERUNG (NEUE LOGIK)
// =============================================================================

bool AudioManager::startRecording() {
    xSemaphoreTake(m_audioMutex, portMAX_DELAY);

    // Wenn schon aufgenommen wird, nichts tun
    if (m_currentState == AudioState::RECORDING) {
        xSemaphoreGive(m_audioMutex);
        return true;
    }
    
    // WICHTIG: Wenn gerade wiedergegeben wird, stoppe es zuerst!
    if (m_currentState == AudioState::PLAYING) {
        xSemaphoreGive(m_audioMutex); // Mutex freigeben, damit stopPlaying arbeiten kann
        stopPlaying();
        xSemaphoreTake(m_audioMutex, portMAX_DELAY); // Mutex wieder holen
    }

    logToWebClients("[AudioManager] Starte Aufnahme...");
    resetRingBuffer(m_micBuffer);
    
    // I2S-Treiber im Mikrofon-Modus installieren
    installI2SDriver(MODE_MIC);

    m_isRecordingTaskRunning = true;
    BaseType_t result = xTaskCreate(
        recordingTask, "RecordingTask", AUDIO_TASK_STACK_SIZE,
        this, AUDIO_TASK_PRIORITY, &m_recordingTaskHandle);

    if (result != pdPASS) {
        char errorMsg[128];
        snprintf(errorMsg, sizeof(errorMsg), "[AudioManager] FEHLER: Recording-Task konnte nicht erstellt werden! Code: %d", result);
        logToWebClients(errorMsg);
        Serial.printf("AudioManager: Task-Erstellung fehlgeschlagen. Result: %d\n", result);
        m_isRecordingTaskRunning = false;
        uninstallI2SDriver();
        changeState(AudioState::IDLE);
        xSemaphoreGive(m_audioMutex);
        return false;
    }

    changeState(AudioState::RECORDING);
    xSemaphoreGive(m_audioMutex);
    return true;
}

void AudioManager::stopRecording() {
    xSemaphoreTake(m_audioMutex, portMAX_DELAY);

    if (m_currentState != AudioState::RECORDING || !m_isRecordingTaskRunning) {
        xSemaphoreGive(m_audioMutex);
        return; // Nichts zu tun
    }

    logToWebClients("[AudioManager] Stoppe Aufnahme...");
    m_isRecordingTaskRunning = false; // Signal an die Task senden, sich zu beenden

    // Warte, bis die Task sich selbst beendet hat.
    // Die Task setzt m_recordingTaskHandle auf NULL, bevor sie sich löscht.
    while (m_recordingTaskHandle != NULL) {
        xSemaphoreGive(m_audioMutex); // Mutex freigeben, damit Task arbeiten kann
        vTaskDelay(pdMS_TO_TICKS(10));
        xSemaphoreTake(m_audioMutex, portMAX_DELAY);
    }
    
    uninstallI2SDriver();
    changeState(AudioState::IDLE);

    xSemaphoreGive(m_audioMutex);
    logToWebClients("[AudioManager] Aufnahme gestoppt.");
}

bool AudioManager::isRecording() const {
    return m_currentState == AudioState::RECORDING;
}

size_t AudioManager::getAvailableAudioDataSize() {
    if (xSemaphoreTake(m_audioMutex, pdMS_TO_TICKS(10)) != pdTRUE) {
        return 0;
    }
    
    size_t available = m_micBuffer.available;
    xSemaphoreGive(m_audioMutex);
    return available;
}

size_t AudioManager::readAudioData(uint8_t* buffer, size_t maxLength) {
    if (!buffer || maxLength == 0) {
        return 0;
    }
    
    if (xSemaphoreTake(m_audioMutex, pdMS_TO_TICKS(10)) != pdTRUE) {
        return 0;
    }
    
    size_t bytesRead = readFromRingBuffer(m_micBuffer, buffer, maxLength);
    xSemaphoreGive(m_audioMutex);
    
    return bytesRead;
}

// =============================================================================
// LAUTSPRECHER-STEUERUNG (NEUE LOGIK)
// =============================================================================

bool AudioManager::playAudioChunk(const uint8_t* data, size_t length) {
    if (!data || length == 0) return false;

    xSemaphoreTake(m_audioMutex, portMAX_DELAY);

    // Wenn gerade aufgenommen wird, stoppe es zuerst!
    if (m_currentState == AudioState::RECORDING) {
        xSemaphoreGive(m_audioMutex);
        stopRecording();
        xSemaphoreTake(m_audioMutex, portMAX_DELAY);
    }

    // Wenn die Wiedergabe noch nicht läuft, starte sie
    if (m_currentState != AudioState::PLAYING) {
        logToWebClients("[AudioManager] Starte Wiedergabe...");
        resetRingBuffer(m_speakerBuffer);
        
        enableAmplifier();

        installI2SDriver(MODE_SPK);

        m_isPlayingTaskRunning = true;
        BaseType_t result = xTaskCreate(
            playingTask, "PlayingTask", AUDIO_TASK_STACK_SIZE,
            this, AUDIO_TASK_PRIORITY, &m_playingTaskHandle);

        if (result != pdPASS) {
            logToWebClients("[AudioManager] FEHLER: Konnte Playing-Task nicht erstellen!");
            m_isPlayingTaskRunning = false;
            uninstallI2SDriver();
            disableAmplifier();
            changeState(AudioState::IDLE);
            xSemaphoreGive(m_audioMutex);
            return false;
        }
        changeState(AudioState::PLAYING);
    }

    // Daten in den Puffer schreiben
    writeToRingBuffer(m_speakerBuffer, data, length);
    
    xSemaphoreGive(m_audioMutex);
    return true;
}

void AudioManager::stopPlaying() {
    xSemaphoreTake(m_audioMutex, portMAX_DELAY);

    if (m_currentState != AudioState::PLAYING || !m_isPlayingTaskRunning) {
        xSemaphoreGive(m_audioMutex);
        return;
    }

    logToWebClients("[AudioManager] Stoppe Wiedergabe...");
    m_isPlayingTaskRunning = false; // Signal an Task

    while (m_playingTaskHandle != NULL) {
        xSemaphoreGive(m_audioMutex);
        vTaskDelay(pdMS_TO_TICKS(10));
        xSemaphoreTake(m_audioMutex, portMAX_DELAY);
    }

    uninstallI2SDriver();
    disableAmplifier();
    changeState(AudioState::IDLE);
    
    xSemaphoreGive(m_audioMutex);
    logToWebClients("[AudioManager] Wiedergabe gestoppt.");
}

bool AudioManager::isPlaying() const {
    return m_currentState == AudioState::PLAYING;
}

// =============================================================================
// FREERTOS-TASKS (NEUE LOGIK)
// =============================================================================

void AudioManager::recordingTask(void* parameter) {
    AudioManager* manager = static_cast<AudioManager*>(parameter);
    uint8_t* audioBuffer = (uint8_t*)malloc(DATA_SIZE);
    
    if (!audioBuffer) {
        logToWebClients("[RecordingTask] FEHLER: Speicherallozierung fehlgeschlagen!");
        manager->m_recordingTaskHandle = NULL;
        vTaskDelete(NULL);
        return;
    }

    logToWebClients("[RecordingTask] Gestartet.");

    while (manager->m_isRecordingTaskRunning) {
        size_t bytesRead = 0;
        esp_err_t result = i2s_read(SPEAKER_I2S_NUMBER, audioBuffer, DATA_SIZE, &bytesRead, pdMS_TO_TICKS(100));
        
        if (result == ESP_OK && bytesRead > 0) {
            manager->amplifyAudioData(audioBuffer, bytesRead);
            
            xSemaphoreTake(manager->m_audioMutex, portMAX_DELAY);
            // Für getCurrentAudioLevel() kopieren
            memcpy(manager->m_lastMicBuffer, audioBuffer, bytesRead);
            manager->m_lastMicBufferSize = bytesRead;
            // In den Ringpuffer schreiben
            manager->writeToRingBuffer(manager->m_micBuffer, audioBuffer, bytesRead);
            xSemaphoreGive(manager->m_audioMutex);
        }
    }

    // Aufräumen
    free(audioBuffer);
    logToWebClients("[RecordingTask] Wird beendet.");
    manager->m_recordingTaskHandle = NULL; // Signal an stopRecording(), dass die Task beendet ist
    vTaskDelete(NULL); // Task löscht sich selbst
}

void AudioManager::playingTask(void* parameter) {
    AudioManager* manager = static_cast<AudioManager*>(parameter);
    uint8_t* audioBuffer = (uint8_t*)malloc(DATA_SIZE);
    
    if (!audioBuffer) {
        logToWebClients("[PlayingTask] FEHLER: Speicherallozierung fehlgeschlagen!");
        manager->m_playingTaskHandle = NULL;
        vTaskDelete(NULL);
        return;
    }

    logToWebClients("[PlayingTask] Gestartet.");
    unsigned long lastDataTime = millis();
    const unsigned long TIMEOUT_MS = 1000; // 1 Sekunde Timeout

    while (manager->m_isPlayingTaskRunning) {
        size_t bytesToRead = 0;
        
        xSemaphoreTake(manager->m_audioMutex, portMAX_DELAY);
        bytesToRead = manager->readFromRingBuffer(manager->m_speakerBuffer, audioBuffer, DATA_SIZE);
        xSemaphoreGive(manager->m_audioMutex);
        
        if (bytesToRead > 0) {
            size_t bytesWritten = 0;
            i2s_write(SPEAKER_I2S_NUMBER, audioBuffer, bytesToRead, &bytesWritten, portMAX_DELAY);
            lastDataTime = millis();
        } else {
            // Wenn keine Daten mehr da sind, prüfe auf Timeout
            if (millis() - lastDataTime > TIMEOUT_MS) {
                logToWebClients("[PlayingTask] Timeout, keine Audiodaten mehr.");
                break; // Schleife verlassen -> Task wird beendet
            }
            vTaskDelay(pdMS_TO_TICKS(10)); // Kurz warten
        }
    }

    // Aufräumen
    free(audioBuffer);
    logToWebClients("[PlayingTask] Wird beendet.");
    
    // Wichtig: stopPlaying() wird von außerhalb aufgerufen oder durch den Timeout hier.
    // Wir setzen hier nur den Handle auf NULL.
    // Der Mutex ist hier kritisch, um Race Conditions zu vermeiden.
    xSemaphoreTake(manager->m_audioMutex, portMAX_DELAY);
    manager->m_playingTaskHandle = NULL; 
    xSemaphoreGive(manager->m_audioMutex);

    // Wenn die Task wegen Timeout beendet wurde, muss der Manager informiert werden.
    // Am einfachsten ist es, die stopPlaying-Funktion aufzurufen.
    if(manager->isPlaying()){
        manager->stopPlaying();
    }
    
    vTaskDelete(NULL);
}

// =============================================================================
// I2S-MANAGEMENT & ANDERE PRIVATE METHODEN
// =============================================================================

void AudioManager::installI2SDriver(int mode) {
    logToWebClients(mode == MODE_MIC ? "[I2S] Installiere Treiber für MIKROFON" : "[I2S] Installiere Treiber für LAUTSPRECHER");
    InitI2SSpeakerOrMic(mode);
    if (mode == MODE_MIC) {
        i2s_zero_dma_buffer(SPEAKER_I2S_NUMBER);
        i2s_start(SPEAKER_I2S_NUMBER);
    }
}

void AudioManager::uninstallI2SDriver() {
    logToWebClients("[I2S] Deinstalliere Treiber");
    i2s_driver_uninstall(SPEAKER_I2S_NUMBER); // Immer SPEAKER_I2S_NUMBER, da beide Modi es benutzen
}

void AudioManager::changeState(AudioState newState) {
    m_currentState = newState;
}

void AudioManager::InitI2SSpeakerOrMic(int mode) {
    esp_err_t err = ESP_OK;

    i2s_driver_uninstall(SPEAKER_I2S_NUMBER);
    i2s_config_t i2s_config = {
        .mode        = (i2s_mode_t)(I2S_MODE_MASTER),
        .sample_rate = 16000,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ALL_RIGHT,
#if ESP_IDF_VERSION > ESP_IDF_VERSION_VAL(4, 1, 0)
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
#else
        .communication_format = I2S_COMM_FORMAT_I2S,
#endif
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count    = 6,
        .dma_buf_len      = 60,
    };
    
    if (mode == MODE_MIC) {
        i2s_config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_PDM);
    } else {
        i2s_config.mode     = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
        i2s_config.use_apll = false;
        i2s_config.tx_desc_auto_clear = true;
    }

    err += i2s_driver_install(SPEAKER_I2S_NUMBER, &i2s_config, 0, NULL);
    i2s_pin_config_t tx_pin_config;

#if (ESP_IDF_VERSION > ESP_IDF_VERSION_VAL(4, 3, 0))
    tx_pin_config.mck_io_num = I2S_PIN_NO_CHANGE;
#endif
    tx_pin_config.bck_io_num   = CONFIG_I2S_BCK_PIN;
    tx_pin_config.ws_io_num    = CONFIG_I2S_LRCK_PIN;
    tx_pin_config.data_out_num = CONFIG_I2S_DATA_PIN;
    tx_pin_config.data_in_num  = CONFIG_I2S_DATA_IN_PIN;

    err += i2s_set_pin(SPEAKER_I2S_NUMBER, &tx_pin_config);
    
    if (err != ESP_OK) {
        Serial.printf("AudioManager: InitI2SSpeakerOrMic Fehler: %s\n", esp_err_to_name(err));
    } else {
        Serial.printf("AudioManager: InitI2SSpeakerOrMic erfolgreich (Mode: %s)\n", 
                     mode == MODE_MIC ? "Mikrofon" : "Lautsprecher");
    }
}

// =============================================================================
// PUFFER-MANAGEMENT
// =============================================================================

void AudioManager::initRingBuffer(AudioRingBuffer& rb, uint8_t* buffer, size_t size) {
    rb.buffer = buffer;
    rb.size = size;
    resetRingBuffer(rb);
}

void AudioManager::resetRingBuffer(AudioRingBuffer& rb) {
    rb.readIndex = 0;
    rb.writeIndex = 0;
    rb.available = 0;
    rb.isFull = false;
    rb.isEmpty = true;
}

size_t AudioManager::writeToRingBuffer(AudioRingBuffer& rb, const uint8_t* data, size_t length) {
    if (!data || length == 0 || rb.isFull) {
        return 0;
    }
    
    size_t bytesToWrite = min(length, rb.size - rb.available);
    
    for (size_t i = 0; i < bytesToWrite; i++) {
        rb.buffer[rb.writeIndex] = data[i];
        rb.writeIndex = (rb.writeIndex + 1) % rb.size;
        rb.available++;
    }
    
    rb.isFull = (rb.available >= rb.size);
    rb.isEmpty = (rb.available == 0);
    
    return bytesToWrite;
}

size_t AudioManager::readFromRingBuffer(AudioRingBuffer& rb, uint8_t* data, size_t maxLength) {
    if (!data || maxLength == 0 || rb.isEmpty) {
        return 0;
    }
    
    size_t bytesToRead = min(maxLength, rb.available);
    
    for (size_t i = 0; i < bytesToRead; i++) {
        data[i] = rb.buffer[rb.readIndex];
        rb.readIndex = (rb.readIndex + 1) % rb.size;
        rb.available--;
    }
    
    rb.isFull = (rb.available >= rb.size);
    rb.isEmpty = (rb.available == 0);
    
    return bytesToRead;
}

void AudioManager::clearMicBuffer() {
    if (xSemaphoreTake(m_audioMutex, pdMS_TO_TICKS(10)) != pdTRUE) {
        return;
    }
    
    resetRingBuffer(m_micBuffer);
    xSemaphoreGive(m_audioMutex);
}

void AudioManager::clearSpeakerBuffer() {
    if (xSemaphoreTake(m_audioMutex, pdMS_TO_TICKS(10)) != pdTRUE) {
        return;
    }
    
    resetRingBuffer(m_speakerBuffer);
    xSemaphoreGive(m_audioMutex);
}

size_t AudioManager::getMicBufferAvailable() const {
    return m_micBuffer.available;
}

size_t AudioManager::getSpeakerBufferAvailable() const {
    return m_speakerBuffer.available;
}

// =============================================================================
// AUDIO-KONFIGURATION
// =============================================================================

void AudioManager::setSampleRate(uint32_t sampleRate) {
    // I2S-Konfiguration neu laden würde hier implementiert werden
    // Für jetzt verwenden wir die Werte aus config.h
}

void AudioManager::setBitsPerSample(uint8_t bitsPerSample) {
    // I2S-Konfiguration neu laden würde hier implementiert werden
}

void AudioManager::setChannels(uint8_t channels) {
    // I2S-Konfiguration neu laden würde hier implementiert werden
}

uint32_t AudioManager::getSampleRate() const {
    return I2S_SAMPLE_RATE;
}

uint8_t AudioManager::getBitsPerSample() const {
    return I2S_BITS_PER_SAMPLE;
}

uint8_t AudioManager::getChannels() const {
    return I2S_CHANNELS;
}

// =============================================================================
// ZUSTANDSABFRAGE
// =============================================================================

AudioState AudioManager::getState() const {
    return m_currentState;
}

bool AudioManager::isSilence() const {
    return m_isSilenceDetected;
}

bool AudioManager::isBufferFull() const {
    return m_micBuffer.isFull;
}

bool AudioManager::isBufferEmpty() const {
    return m_micBuffer.isEmpty;
}

// =============================================================================
// UTILITY-METHODEN
// =============================================================================

void AudioManager::reset() {
    stopRecording();
    stopPlaying();
    clearMicBuffer();
    clearSpeakerBuffer();
    changeState(AudioState::IDLE);
    m_silenceCounter = 0;
    m_isSilenceDetected = false;
}

void AudioManager::setSilenceThreshold(int threshold) {
    m_silenceThreshold = threshold;
}

int AudioManager::getSilenceThreshold() const {
    return AUDIO_SILENCE_THRESHOLD;
}

unsigned long AudioManager::getLastAudioTimestamp() const {
    return m_lastAudioProcess;
}

// =============================================================================
// DEBUG-METHODEN
// =============================================================================

void AudioManager::printBufferStatus() {
    Serial.printf("AudioManager: Mic Buffer - Available: %d, Full: %s, Empty: %s\n",
                  m_micBuffer.available,
                  m_micBuffer.isFull ? "true" : "false",
                  m_micBuffer.isEmpty ? "true" : "false");
    
    Serial.printf("AudioManager: Speaker Buffer - Available: %d, Full: %s, Empty: %s\n",
                  m_speakerBuffer.available,
                  m_speakerBuffer.isFull ? "true" : "false",
                  m_speakerBuffer.isEmpty ? "true" : "false");
}

void AudioManager::printAudioStats() {
    Serial.printf("AudioManager: State: %d, Recording: %s, Playing: %s, Silence: %s\n",
                  (int)m_currentState,
                  m_isRecordingTaskRunning ? "enabled" : "disabled",
                  m_isPlayingTaskRunning ? "enabled" : "disabled",
                  m_isSilenceDetected ? "detected" : "none");
}

// =============================================================================
// EVENT-INTEGRATION
// =============================================================================

void AudioManager::setEventManager(EventManager* manager) {
    m_eventManager = manager;
    Serial.println("AudioManager: EventManager gesetzt");
}

bool AudioManager::playChunk(const uint8_t* data, size_t size) {
    return playAudioChunk(data, size);
}

bool AudioManager::playTestTone() {
    Serial.println("AudioManager: Spiele Test-Ton ab...");
    
    // Test-Ton generieren (einfache Stille)
    const size_t testToneSize = 1024;
    uint8_t* testTone = (uint8_t*)malloc(testToneSize);
    if (!testTone) {
        Serial.println("AudioManager: Fehler beim Allozieren des Test-Ton-Buffers");
        return false;
    }
    
    // Einfacher Test-Ton (alle Samples auf 0 für Stille)
    memset(testTone, 0, testToneSize);
    
    bool result = playAudioChunk(testTone, testToneSize);
    free(testTone);
    return result;
}

// =============================================================================
// DEBUG-FUNKTIONEN
// =============================================================================

uint16_t AudioManager::getCurrentAudioLevel() {
    if (!isRecording()) {
        return 0; // Gib 0 zurück, wenn die Task nicht läuft
    }
    
    if (!m_lastMicBuffer || m_lastMicBufferSize == 0) {
        return 0;
    }
    
    // Mutex nehmen für sicheren Zugriff auf den Mikrofon-Puffer
    if (xSemaphoreTake(m_audioMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
        return 0;
    }
    
    // RMS-Wert aus dem letzten Mikrofon-Puffer berechnen
    long sum = 0;
    size_t sampleCount = 0;
    
    // Samples als 16-bit Werte interpretieren
    int16_t* samples = (int16_t*)m_lastMicBuffer;
    size_t maxSamples = m_lastMicBufferSize / 2; // 16-bit = 2 Bytes pro Sample
    
    // Maximal 512 Samples für die Berechnung verwenden
    size_t samplesToProcess = min(maxSamples, (size_t)512);
    
    for (size_t i = 0; i < samplesToProcess; i++) {
        int16_t sample = samples[i];
        sum += abs(sample);
        sampleCount++;
    }
    
    xSemaphoreGive(m_audioMutex);
    
    // Durchschnittlichen Absolutwert berechnen
    unsigned int average_level = 0;
    if (sampleCount > 0) {
        average_level = (uint16_t)(sum / sampleCount);
    }

    return average_level;
}

// =============================================================================
// AUDIO-VERSTÄRKUNG (Performance-optimiert)
// =============================================================================

void AudioManager::amplifyAudioData(uint8_t* data, size_t length) {
    if (!data || length == 0) {
        return;
    }
    
    // Das uint8_t Array als int16_t (16-bit Samples) interpretieren
    int16_t* samples = (int16_t*)data;
    int num_samples = length / 2; // Da jeder Sample 2 Bytes hat
    
    // PERFORMANCE: Serial.printf-Aufrufe entfernt für bessere Performance!
    
    for (int i = 0; i < num_samples; i++) {
        // Sample auslesen, verstärken und als 32-bit float berechnen
        float amplified_sample = (float)samples[i] * AUDIO_VOLUME_GAIN;
        
        // Clipping: Verhindert Übersteuerung und Verzerrung
        if (amplified_sample > AUDIO_MAX_SAMPLE) {
            amplified_sample = AUDIO_MAX_SAMPLE;
        } else if (amplified_sample < AUDIO_MIN_SAMPLE) {
            amplified_sample = AUDIO_MIN_SAMPLE;
        }
        
        // Verstärkten und geclippten Wert zurück in den Puffer schreiben
        samples[i] = (int16_t)amplified_sample;
    }
}

// =============================================================================
// VERSTÄRKER-STEUERUNG
// =============================================================================

void AudioManager::enableAmplifier() {
    Serial.println("[AudioManager] Powering ON amplifier chip...");
    digitalWrite(SPEAKER_ENABLE_PIN, HIGH);
    delay(10); // Kurze Verzögerung von 10ms zur Stabilisierung
    Serial.println("[AudioManager] Amplifier chip powered ON.");
}

void AudioManager::disableAmplifier() {
    Serial.println("[AudioManager] Powering OFF amplifier chip...");
    digitalWrite(SPEAKER_ENABLE_PIN, LOW);
    Serial.println("[AudioManager] Amplifier chip powered OFF.");
}

// =============================================================================
// STILLE-ERKENNUNG
// =============================================================================

bool AudioManager::detectSilence(const uint8_t* data, size_t length) {
    if (!data || length == 0) {
        return true;
    }
    
    // Einfache Stille-Erkennung basierend auf RMS
    int32_t sum = 0;
    for (size_t i = 0; i < length; i += 2) {
        if (i + 1 < length) {
            int16_t sample = (data[i + 1] << 8) | data[i];
            sum += abs(sample);
        }
    }
    
    int32_t average = sum / (length / 2);
    return average < AUDIO_SILENCE_THRESHOLD;
}